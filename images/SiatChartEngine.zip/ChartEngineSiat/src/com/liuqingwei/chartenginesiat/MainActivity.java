package com.liuqingwei.chartenginesiat;

import com.liuqingwei.siatchartengine.DrawView;
import com.liuqingwei.siatchartengine.Renderer;
import com.liuqingwei.util.PostRequest;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.LinearLayout;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		init();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	 private void init() {
	        LinearLayout layout=(LinearLayout) findViewById(R.id.root);
	        /* 创建心电图渲染器 */
	        Renderer renderer = new Renderer();
	        /*
	         * 设置是否显示标题文字
	         * 默认为false不显示
	         */
	        renderer.setSiatShowLabel(true);
	        /* 标题文字内容 */
	        renderer.setSiatChartLabel("这是测试的心电图");
	        /*
	         * 设置标题字体大小
	         * 默认字体大小为24
	         */
	        //renderer.setSiatChartTextSize(30);
	        /*
	         * 设置表格步进数1-10
	         * 步进数越小，绘制速度越慢，绘制越精确
	         * 步进越大，绘制速度越快，图像越粗糙
	         * 默认步进值为1
	         */
	        renderer.setSiatLineStep(1);
	        /* 设置是否可以左右滑动表格来动态加载上一页、下一页内容
	         * 默认值为true可滑动
	         */
	        //renderer.setSiatScrollable(true);

	        /*
	         * 设置是否显示红色的横纵坐标线
	         * 默认true显示
	         */
	        //renderer.setSiatShowAxes(true);
	        /*
	         * 构造提交数据类
	         */
	        PostRequest post = new PostRequest();
	        /* 设置提交类事件ID */
	        post.setEventId("53b64a8611dbae4910000003");
	        /* 设置起始页码 */
	        post.setPage(1);
	        /* 设置数据提交URL */
	        post.setUrl("http://www.bit-health.com/ecg/drawEcg.php");

	        DrawView view=new DrawView(this,renderer,post);
	        view.setMinimumHeight(400);
	        view.setMinimumWidth(500);

	        //通知view组件重绘
	        view.invalidate();
	        layout.addView(view);
	    }
}
